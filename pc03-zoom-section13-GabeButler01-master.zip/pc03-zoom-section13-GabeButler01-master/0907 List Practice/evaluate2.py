assert type(alist) == type([])
assert len(rainbow) == 7
assert rainbow == list(reversed(rainbow_backwards))
print('Good job!')