'''
Turtle starter code
ATLS 1300
Author: Dr. Z
Author: YOUR NAME GOES HERE <----------
May 29, 2020

PROGRAM DESCRIPTION GOES HERE <---------
'''
import turtle #import the library of commands that you'd like to use
import math #get a bunch of math commands

turtle.colormode(255)

# Create a panel to draw on. 
panel = turtle.Screen()
w = 750 # width of panel
h = 750 # height of panel
panel.setup(width=w, height=h) #600 x 600 is a decent size to work on. 
#You can experiment by making it the size of your screen or super tiny!

#=======Add your code here======

panel.bgcolor("maroon") # set background color
#turtle.tracer(0) # turn off the animation  #uncomment along with line 33. ALWAYS update the panel!

turtle.Turtle(visible=False) # create a turtle, make it invisible 

#===================
# YOUR CODE HERE!


#panel.update() # if the animation is off (line 25 is uncommented), then uncomment this line.
#===================
# turtle.done()
